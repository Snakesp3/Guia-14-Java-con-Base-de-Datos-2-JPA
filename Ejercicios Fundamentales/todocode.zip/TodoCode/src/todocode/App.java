/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package todocode;

import Entidades.Alumno;
import Persistencia.ControladoraDePersistencia;
import Persistencia.exceptions.NonexistentEntityException;
import Servicios.ServicioAlumno;
//
/**
 *
 * @author nico_
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NonexistentEntityException, Exception {

        ControladoraDePersistencia controladora = new ControladoraDePersistencia();
//
        ServicioAlumno servalu = new ServicioAlumno();

//        servalu.nuevo();
//
//        servalu.eliminacion();
//
//        servalu.editar();
        
        Alumno alu = servalu.buscar(7);
        System.out.println("El alumno es" + alu.toString());

//        
    }

}
