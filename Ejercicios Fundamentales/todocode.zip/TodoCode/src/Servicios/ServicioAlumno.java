/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Alumno;
import Persistencia.ControladoraDePersistencia;
import Persistencia.exceptions.NonexistentEntityException;
import java.util.Scanner;

/**
 *
 * @author nico_
 */
public class ServicioAlumno {

    ControladoraDePersistencia controlper = new ControladoraDePersistencia();
    Scanner leer = new Scanner(System.in);

    public void nuevo() throws Exception {
        Alumno alu = null;
        System.out.println("Ingrese el id del alumno");
        long id = leer.nextLong();
        System.out.println("Ingrese el nombre");
        String nombre = leer.next();
        System.out.println("Ingrese la edad del alumno");
        int edad = leer.nextInt();

        alu = new Alumno(id, nombre, edad);

        controlper.crear(alu);

    }

    public void eliminacion() throws NonexistentEntityException {

        System.out.println("Ingrese el id del alumno a eliminar");
        Long id = leer.nextLong();
        controlper.eliminar(id);
    }

    public void editar() throws Exception {

        Alumno alu2 = null;
        System.out.println("Ingrese el id del alumno");
        long id = leer.nextLong();
        System.out.println("Ingrese el nombre");
        String nombre = leer.next();
        System.out.println("Ingrese la edad del alumno");
        int edad = leer.nextInt();

        alu2 = new Alumno(id, nombre, edad);

        controlper.crear(alu2);

        System.out.println("Ingrese el nuevo nombre");

        alu2.setNombre(leer.next());

        controlper.editar(alu2);

    }

    public Alumno buscar(long id) {

        return controlper.encontrar(id);
    }
}
