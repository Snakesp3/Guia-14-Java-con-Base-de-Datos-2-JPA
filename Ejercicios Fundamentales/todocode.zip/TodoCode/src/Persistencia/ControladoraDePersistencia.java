/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Entidades.Alumno;
import Persistencia.exceptions.NonexistentEntityException;

/**
 *
 * @author nico_
 */
public class ControladoraDePersistencia {
    
    AlumnoJpaController jpacontrol = new AlumnoJpaController ();

    public void crear(Alumno alu) {
        jpacontrol.create(alu);
    }
    
    public void eliminar ( Long id ) throws NonexistentEntityException{
        jpacontrol.destroy(id);
    }
    
    public void editar(Alumno alu) throws Exception{
        jpacontrol.edit(alu);
    }
    
    public Alumno encontrar(Long id){
        return jpacontrol.findAlumno(id);
    }
    
    
    
}
